<?php
/**
 * Plugin Name: Custom Events Plugin
 * Description: Custom plugin to manage and display events.
 * Version: 1.0
 * Author:Adonis Hamad
 */


function custom_events_post_type() {
    $labels = array(
        'name'               => 'Events',
        'singular_name'      => 'Event',
        'menu_name'          => 'Events',
        'public'             => true,
        'has_archive'        => true,
        'supports'           => array('title', 'editor', 'thumbnail', 'custom-fields'),
    );
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'rewrite'            => array('slug' => 'events'),
        'has_archive'        => true,
        'menu_position'      => 5,
        'menu_icon'          => 'dashicons-calendar',
        'supports'           => array('title', 'editor', 'thumbnail', 'custom-fields'),
    );
    register_post_type('events', $args);
}
add_action('init', 'custom_events_post_type');

function custom_events_taxonomy() {
    $labels = array(
        'name'              => 'Event Categories',
        'singular_name'     => 'Event Category',
        'search_items'      => 'Search Event Categories',
        'all_items'         => 'All Event Categories',
        'parent_item'       => 'Parent Event Category',
        'parent_item_colon' => 'Parent Event Category:',
        'edit_item'         => 'Edit Event Category',
        'update_item'       => 'Update Event Category',
        'add_new_item'      => 'Add New Event Category',
        'new_item_name'     => 'New Event Category',
        'menu_name'         => 'Event Categories',
    );
    $args = array(
        'hierarchical'      => true,
      
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array('slug' => 'event-category'),
    );
    register_taxonomy('event_category', array('events'), $args);
}
add_action('init', 'custom_events_taxonomy');
function custom_events_shortcode($atts) {
    $args = array(
        'post_type'      => 'events',
        'posts_per_page' => -1,
    );

    $events_query = new WP_Query($args);

    $output = '<ul>';

    while ($events_query->have_posts()) {
        $events_query->the_post();

        // Get the event categories using wp_get_post_terms
        $categories = wp_get_post_terms(get_the_ID(), 'event_category');

        $output .= '<li><a href="' . get_permalink() . '">' . get_the_title() . '</a>';

        if ($categories && !is_wp_error($categories)) {
            $category_names = array();
            foreach ($categories as $category) {
                $category_names[] = $category->name;
            }
            $output .= '<div>Categories: ' . implode(', ', $category_names) . '</div>';
        }

        $output .= '<div>' . get_the_content() . '</div></li>';
    }

    $output .= '</ul>';

    wp_reset_postdata();

    return $output;
}
add_shortcode('custom_events', 'custom_events_shortcode');


